from .core import text_to_speech, get_available_languages, get_available_tlds, display_available_options

__version__ = "0.1.1"